import sys
import random

def hangman():
    print("Witaj w swiecie wisielca, podaj swoj nick: ")
    pseudonim = input()
    lista = ["komputer", "python", "programowanie", "informatyka", "cyberbezpieczeństwo"]
    haslo = str(lista[random.randint(0, len(lista) - 1)])
    tablica = list(haslo)

    for i in range(len(haslo)):
        tablica[i] = "_"

    zycia = 6
    run = True
    while run:
        print("")
        print(pseudonim, " pozostalo ci ", zycia, " zyc")
        print("")
        print(" ".join(tablica))
        print(" ")
        print("Podaj swoja litere: ")
        litera = input()

        if litera in haslo:
            for i in range(len(haslo)):
                if haslo[i] == litera:
                    tablica[i] = litera
            if "".join(map(str, tablica)) == haslo:
                print("")
                print(pseudonim, " pozostalo ci ", zycia, " zyc")
                print("")
                print(" ".join(tablica))
                print(" ")
                print(pseudonim, " wygrales!")
                odp = input("Jeszcze raz? Tak/Nie: ")
                if odp == "Tak":
                    hangman()
                elif odp == "Nie":
                    sys.exit()
        else:
            zycia -= 1
        if zycia == 0:
            print(pseudonim, "przegrałeś!")
            odp = input("Jeszcze raz? Tak/Nie: ")
            if odp == "Tak":
                hangman()
            elif odp == "Nie":
                sys.exit()

hangman()

import pygame
from random import randint
import time

pygame.init()
window = pygame.display.set_mode((1280, 720))


class Player:
    def __init__(self):
        self.x_cord = 0
        self.y_cord = 150
        self.image = pygame.image.load("gracz.png")
        self.width = self.image.get_width()
        self.height = self.image.get_height()
        self.speed = 15
        self.hitbox = pygame.Rect(self.x_cord, self.y_cord, self.width, self.height)

    def tick(self, keys):
        if keys[pygame.K_w]:
            self.y_cord -= self.speed
        if keys[pygame.K_a]:
            self.x_cord -= self.speed
        if keys[pygame.K_s]:
            self.y_cord += self.speed
        if keys[pygame.K_d]:
            self.x_cord += self.speed
        if keys[pygame.K_UP]:
            self.y_cord -= self.speed
        if keys[pygame.K_LEFT]:
            self.x_cord -= self.speed
        if keys[pygame.K_DOWN]:
            self.y_cord += self.speed
        if keys[pygame.K_RIGHT]:
            self.x_cord += self.speed

        self.hitbox = pygame.Rect(self.x_cord, self.y_cord, self.width, self.height)

    def draw(self):
        window.blit(self.image, (self.x_cord, self.y_cord))


class Cash:
    def __init__(self):
        self.x_cord = randint(0, 1280)
        self.y_cord = randint(0, 720)
        self.image = pygame.image.load("banknot.png")
        self.width = self.image.get_width()
        self.height = self.image.get_height()
        self.hitbox = pygame.Rect(self.x_cord, self.y_cord, self.width, self.height)

    def tick(self):
        self.hitbox = pygame.Rect(self.x_cord, self.y_cord, self.width, self.height)

    def draw(self):
        window.blit(self.image, (self.x_cord, self.y_cord))


def main():
    writing = -1
    run = True
    player = Player()
    clock = 0
    score = 0
    banknotes = []
    background = pygame.image.load("tło.png")
    while run:
        clock += pygame.time.Clock().tick(60) / 1000
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
        keys = pygame.key.get_pressed()
        if clock >= 1:
            clock = 0
            banknotes.append(Cash())

        player.tick(keys)
        for banknote in banknotes:
            banknote.tick()

        score_image = pygame.font.Font.render(pygame.font.SysFont("Calibra", 72), f"Wynik: {score}", True, (0, 0, 0))

        if score == 5:
            score_image = pygame.font.Font.render(pygame.font.SysFont("Calibri", 120), f"BRAWO!!!", True, (0, 0, 0))
            writing = 5
        if score == 10:
            score_image = pygame.font.Font.render(pygame.font.SysFont("Calibri", 120), f"SUPER!!!", True, (0, 0, 0))
            writing = 10
        if score == 15:
            score_image = pygame.font.Font.render(pygame.font.SysFont("Calibri", 120), f"NIEŹLE!!!", True, (0, 0, 0))
            writing = 15
        if score == 20:
            score_image = pygame.font.Font.render(pygame.font.SysFont("Calibri", 120), f"MEGA!!!", True, (0, 0, 0))
            writing = 20
        if score == 30:
            score_image = pygame.font.Font.render(pygame.font.SysFont("Calibri", 30), f"JESTEŚ ZA MOCNY NASTĘPNY PUNKT KOŃCZY GRE!!!", True, (0, 0, 0))
            writing = 30

        if score == 31:
            run = False

        for banknote in banknotes:
            if player.hitbox.colliderect(banknote.hitbox):
                banknotes.remove(banknote)
                score += 1

        window.blit(background, (0, 0))
        if score != writing:
            window.blit(score_image, (0, 0))
        else:
            window.blit(score_image, (400, 300))
        player.draw()
        for banknote in banknotes:
            banknote.draw()
        pygame.display.update()

    print(score)

if __name__ == "__main__":
    main()
